from imov.main import main


def run():
   main()