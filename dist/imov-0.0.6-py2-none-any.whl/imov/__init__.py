from imov.main import save


def run():
   save()